1) Install minority_setup.exe
2) Run Minority
3) Sign in or sign up with your email address
4) Enter your key
5) Press "START"
6) Run Dota 2 and enjoy
